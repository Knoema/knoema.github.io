(function () {

	app = function () {	};

	app.prototype.run = function () {

		var self = this;
		this.infoWindow = new google.maps.InfoWindow();
		this.clients = [];
		this.credit = [];
		this.savings= [];
		this.total = [];	
		this.layers = {};
		this.flag = false;
		this.settings = {};
		this.count = 0;
		this.meta = {
			'branches': '8576b262-f9be-684a-b2e8-002339c4bf36',
			'branches-credit': '9bc1f577-16c9-097c-3f2d-debfd645d5bb',
			'branches-savings': '01063b13-f472-253c-d09f-bfc20ac16daa',
			'branches-total': 'fcd0a098-e20b-f47f-c38b-962b83dc0b73',
			'projects': '9d80eb9f-b542-632a-e6b3-d3c88f681421'
		};
		this.layers = {};
		this.view = 'map';
		this.loans = null;

		this.map = new google.maps.Map(document.getElementById('map-canvas'), {
			center: { lat: 6.363070, lng: 6.795044 },
			zoom: 7,
			streetViewControl: false,
			zoomControlOptions: {
				position: google.maps.ControlPosition.LEFT_TOP
			},
			mapTypeId: google.maps.MapTypeId.HYBRID
		});

		google.maps.event.addListenerOnce(this.map, 'idle', function () {
			var idleTimeout = window.setTimeout(function () {				

				self.bubblesLayer = new Knoema.GeoPlayground.BubblesLayer(self.map);
				self.load('branches');
				self.load('projects');

			}, 300);
		});

		this.bindEvents();
	};

	app.prototype.loadLoan = function (member, callback) {

		Knoema.Helpers.post('/api/1.0/data/details', {	
			"Filter": [
				{
					"DimensionId": "boa-branch",
					"Members": [
						member
					],
					"DimensionName": "BoA Branch",
					"DatasetId": "kauagwc",
					"Order": "0"
				}
			],
			"Frequencies": [],
			"Dataset": "kauagwc",
		},
		function (response) {
			callback(response);
		});
	};

	app.prototype.load = function (id) {

		var self = this;
	
		var layer = this.layers[id];

		$(document.body).addClass('loading');

		if (!layer) {

			var layer = new GeoPlayground.Layer({
				map: self.map,
				layerId: this.meta[id],
				geoPlaygroundId: 'cpfelie',
				bubblesLayer: self.bubblesLayer
			}, function (e) {

				$(document.body).removeClass('loading');

				if (id.indexOf('branches') > -1) {
					$('.count label').text('NUMBER OF BRANCHES: ' + self.count);
					self.fillFilters();
				}
			});

			layer.on('click', function (e) {
				self.tooltip(e, id);
			});

			layer.on('beforeDraw', function (e, callback) {
				self.onBeforeDraw(e, callback, id);
			});

			self.layers[id] = layer;
		}

		layer.load();
	}

	app.prototype.clean = function (id) {

		var layer = this.layers[id];
		
		if (layer)
			layer.clean();

		if (id.indexOf('branches') > -1) {
			$('#table tbody').empty();
			this.count = 0;
		}
	};

	app.prototype.update = function (id) {
		this.clean(id);
		this.load(id);
	};

	app.prototype.tooltip = function (event, id) {

		var data = event.data.tooltip;
		var copy = $.extend({}, data);

		for (var key in copy) {
			if ($.isNumeric(copy[key]))
				copy[key] = parseFloat(copy[key]).toLocaleString();
		};

		var self = this;

		switch (id) {
			case 'projects':
				this.infoWindow.setContent($('<div>').append($('#tmpl-project-profile').tmpl({ data: copy })).html());
				this.infoWindow.setPosition(event.data.latLng);
				this.infoWindow.open(this.map);
				break;
			default:

				$('#branch-profile h1').text(data['Business Outlets']);
				$('#branch-profile .tab.general').html($('#tmpl-branch-profile').tmpl({ data: copy }));
				$('#branch-profile .tab.loans').html($('#tmpl-loans').tmpl({ data: copy }));

				$('.nav-tabs a').first().click();
				$('#branch-profile').show();
				break;
		}
	};

	app.prototype.fillFilters = function (data) {

		var self = this;

		if (this.flag)
			return;

		this.flag = true;

		function sortNumbers(a, b) {
			return a - b;
		}

		this.clients.sort(sortNumbers);
		this.credit.sort(sortNumbers);
		this.savings.sort(sortNumbers);
		this.total.sort(sortNumbers);

		this.settings['search'] = '';

		this.settings['clients'] = {
			min: this.clients[0],
			max: this.clients[this.clients.length - 1],
			_min: this.clients[0],
			_max: this.clients[this.clients.length - 1],
		};

		this.settings['credit'] = {
			min: this.credit[0],
			max: this.credit[this.credit.length - 1],
			_min: this.credit[0],
			_max: this.credit[this.credit.length - 1]
		};

		this.settings['savings'] = {
			min: this.savings[0],
			max: this.savings[this.savings.length - 1],
			_min: this.savings[0],
			_max: this.savings[this.savings.length - 1]
		};

		this.settings['total'] = {
			min: this.total[0],
			max: this.total[this.total.length - 1],
			_min: this.total[0],
			_max: this.total[this.total.length - 1]
		};

		this.settings['grade'] = ['A', 'B', 'C', 'D'];

		this.setup('clients');
		this.setup('credit');
		this.setup('savings');
		this.setup('total');

		$('#rating-grade').selectpicker();

		$('#rating-grade').change(function () {
			self.settings['grade'] = $('#rating-grade').selectpicker('val');
			self.update($('#size').val());
		});

		$('#filters').show();
	};

	app.prototype.setup = function (id) {

		var self = this;
		var setting = this.settings[id];
		var container = $('.' + id);
	
		var min = container.find('.min');
		var max = container.find('.max');
		var slider = container.find('.slider');

		min.val(format(setting.min));
		max.val(format(setting.max));

		function format(value) {
			return value.toLocaleString();
		}

		min.change(function () {

			var value = parseFloat($(this).val());

			if ($.isNumeric(value) && value <= setting._max && value >= setting._min) {
				setting.min = value;
				slider.slider('option', 'values', [setting.min, setting.max]);
				self.update($('#size').val());
			}
			
			min.val(format(setting.min));
			
		});

		max.change(function () {

			var value = parseFloat($(this).val());

			if ($.isNumeric(value) && value <= setting._max && value >= setting._min) {
				setting.max = value;
				slider.slider('option', 'values', [setting.min, setting.max]);
				self.update($('#size').val());
			}
			
			max.val(format(setting.max));
			
		});

		slider.slider({
			range: true,
			min: setting.min,
			max: setting.max,
			values: [setting.min, setting.max],
			change: function (event, ui) {

				self.settings[id] = {
					min: ui.values[0],
					max: ui.values[1]
				}

				min.val(format(self.settings[id].min));
				max.val(format(self.settings[id].max));

				self.update($('#size').val());
			}
		});
	};

	app.prototype.onBeforeDraw = function (event, callback, id) {
		
		if (id.indexOf('branches') == -1)
			return callback(event.data);

		if (!$.isNumeric(event.data.radius))
			return callback(event.data);
		
		event.data.visible = true;
		
		var data = event.data.content;
		var clients = $.isNumeric(parseFloat(data['Number of Clients'])) ? parseFloat(data['Number of Clients']) : 0;
		var credit = $.isNumeric(parseFloat(data['Total ratings, Credit'])) ? parseFloat(data['Total ratings, Credit']) : 0;
		var savings = $.isNumeric(parseFloat(data['Total ratings, Savings'])) ? parseFloat(data['Total ratings, Savings']) : 0;
		var total = $.isNumeric(parseFloat(data['Total ratings, Total'])) ? parseFloat(data['Total ratings, Total']) : 0;
		var grade = data['Total ratings, Grade'];
		var name = data['Business Outlets'];
		var search = this.settings['search'] || '';

		if (!this.flag) {
			if ($.isNumeric(clients) && this.clients.indexOf(clients) == -1)
				this.clients.push(clients);

			if ($.isNumeric(credit) && this.credit.indexOf(credit) == -1)
				this.credit.push(credit);

			if ($.isNumeric(savings) && this.savings.indexOf(savings) == -1)
				this.savings.push(savings);

			if ($.isNumeric(total) && this.total.indexOf(total) == -1)
				this.total.push(total);
		}
		else {

			var visible = true;

			if (visible && $.isNumeric(clients)) 
				visible = clients >= this.settings['clients'].min && clients <= this.settings['clients'].max;
			
			if (visible && $.isNumeric(credit)) 
				visible = credit >= this.settings['credit'].min && credit <= this.settings['credit'].max;
			
			if (visible && $.isNumeric(savings)) 
				visible = savings >= this.settings['savings'].min && savings <= this.settings['savings'].max;
			
			if (visible && $.isNumeric(total)) 
				visible = total >= this.settings['total'].min && total <= this.settings['total'].max;			

			if (visible && grade) 
				visible = this.settings['grade'].indexOf(grade) > -1;			

			if (visible && search != '' && name.toLowerCase().indexOf(search) > -1)
				event.data.fillColor = '#CC3333';
		
			event.data.visible = visible;
		}

		if (event.data.visible) {

			var copy = $.extend({}, data);

			for (var key in copy) {
				if ($.isNumeric(copy[key]))
					copy[key] = parseFloat(copy[key]).toLocaleString();
			};

			this.count++;

			var row = $('#tmpl-branch').tmpl({ data: copy });
			
			if (search != '' && row.find('td.name').text().toLowerCase().indexOf(search) > -1)
				row.css('background-color', '#FF908E');
				
			$('#table tbody').append(row);
		}

		callback(event.data);
	}

	app.prototype.bindEvents = function () {

		var self = this;

		$('#map-view').on('click', function () {

			$('#main-menu').find('.btn').removeClass('active');
			$(this).addClass('active');
			self.switchView('map');
		});

		$('#table-view').on('click', function () {

			$('#main-menu').find('.btn').removeClass('active');
			$(this).addClass('active');
			self.switchView('table');
		});

		$('#projects').on('click', function () {
			if (this.checked)
				self.load('projects');
			else
				self.clean('projects');
		});

		$('#size').change(function () {

			var layerId = $(this).val();

			for (var id in self.meta)
				if (id.indexOf('branches') > -1)
					self.clean(id);

			self.load(layerId);
		});

		var delay = (function () {
			var timer = 0;
			return function (callback, ms) {
				clearTimeout(timer);
				timer = setTimeout(callback, ms);
			};
		})();

		$('input').keyup(function () {
			delay(function () {
				self.settings['search'] = $.trim($(this).val().toLowerCase());
				self.update($('#size').val());
			}.bind(this), 200);
		});

		$('.back-button a').on('click', function () {
			$('#branch-profile').hide();
			return false;
		});

		$('#branch-profile').find('.nav-tabs a').click(function () {

			var tab = $(this).data('tab-name');		

			$(this).tab('show');

			$('#branch-profile .tab').removeClass('active');
			$('#branch-profile .tab.' + tab).addClass('active');
			$('#branch-profile iframe').height($('#content').height() - 150);
			return false;
		});

		$(document).on('click', '.passport__close', function (event) {
			$(event.target).closest('.passport-popup').hide();
		});

		$('.region-profile-button').on('click', function () {

			var region = $('#regions').val();
			if (region == -1)
				return false;

			$('#tmpl-region-profile').tmpl({ regionId: region }).appendTo('#content');

			return false;
		});
	};
	
	app.prototype.switchView = function (viewName) {

		switch (viewName) {

			case 'map':

				$('#table').hide();
				$('#map-canvas').show();
				$('#search-control input').val('');
				break;

			case 'table':
				$('#table').show();
				$('#map-canvas').hide();
				$('.table').stickyTableHeaders();
				
				break;
		}

		self.view = viewName;
	};
	
	google.maps.event.addDomListener(window, 'load', function () {
		new app().run();
	});
})();